

#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include "ui_chatdialog.h"
#include "client.h"
#include "imageserver.h"
#include <QUdpSocket>
#include <peermanager.h>
#include <QTime>
class QTimer;
class QUdpSocket;

class ChatDialog : public QDialog, private Ui::ChatDialog
{
    Q_OBJECT

public:
    ChatDialog(QWidget *parent = 0);
    QString time1, time2;

public slots:
    void appendMessage(const QString &from, const QString &message);
    //void Mouse_Pressed();

private slots:
    void returnPressed();
    void newParticipant(const QString &nick);
    void participantLeft(const QString &nick);
    void showInformation();
    void sendID();
    void sendIDr();
    void startBroadcasting();
    void broadcastDatagram();
    void processPendingDatagrams();
    void RTcounter();
    void RTcounter1();
    int reRT(QString time1);
    void reRT1();
    void reRT2();
    void LEDBlinky();
    void LEDBlinky1();
    void LEDGreen();
    void LEDGreen1();
    void Msg();
    void ChangeColor1();
    void ChangeColor2();
    void ImageProcess(QByteArray data);
    void ViewImage();
private:
    Client client;
    PeerManager *peer;
    QString myNickName;
    QString TrafficStatement,WeatherStatement;
    //QMessageBox *mbox;
    QTextTableFormat tableFormat;
    int k;
    int numerr;
    int testBER;
    int RT;
    int start;
    int broadcast;
    //QString time1;
    QUdpSocket *udpSocket;
    QUdpSocket *udpSocket1;
    QTimer *timer;
    QTimer *timer1;
    QTimer *timer2;
    int messageNo;
    QHostAddress IP;
    QTime t1;
    QTime t2;
    ImageServer server;
    QImage image;
    
};

#endif
