#ifndef MYTHREAD_H
#define MYTHREAD_H
#include <QtCore>
#include "chatdialog.h"

class MyThread : public QThread, private Ui::ChatDialog
{
public:
    MyThread();
    void run();
    QString name;
    bool Stop;
};

#endif // MYTHREAD_H
