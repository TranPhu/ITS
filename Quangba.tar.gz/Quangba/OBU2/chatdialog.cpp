#include <QtGui>
#include "chatdialog.h"
#include <QPixmap>
#include "imageserver.h"
#include "QtGui"
#include "my_qlabel.h"
ChatDialog::ChatDialog(QWidget *parent)
    : QDialog(parent)
{
    //startBroadcasting();
    //this->setWindowState(Qt::WindowFullScreen);
    RT = 0;
    setupUi(this);
    k=0;
    numerr=0;
    testBER=0;
    //lineEdit->setFocusPolicy(Qt::StrongFocus);
    textEdit->setFocusPolicy(Qt::NoFocus);
    textEdit->setReadOnly(true);
    listWidget->setFocusPolicy(Qt::NoFocus);
    timer = new QTimer(this);
    timer1 = new QTimer(this);
    timer1->setInterval(300);
    timer2 = new QTimer(this);
    timer2->setInterval(500);
    udpSocket = new QUdpSocket(this);
    udpSocket1 = new QUdpSocket(this);
    //udpSocket1->bind(54545, QUdpSocket::ShareAddress);
    udpSocket1->bind(QHostAddress::QHostAddress("10.42.43.10"), 54545);
    //server = new QTcpServer(this);
    //server->listen(QHostAddress::Any, 1234);
    //socket = server->nextPendingConnection();
    messageNo = 1;
    broadcast = 0;
    //ImageServer *server = new ImageServer();
    connect(&server, SIGNAL(dataReceived(QByteArray)),this, SLOT(ImageProcess(QByteArray)));
    //connect(this->lbViewImage,SIGNAL(Mouse_Pressed()),this,SLOT(ViewImage()));

   // connect(pushButton, SIGNAL(clicked()), this, SLOT(startBroadcasting()));
    //connect(pushButton_2, SIGNAL(clicked()), this, SLOT(close()));
    //connect(socket, SIGNAL(readyRead()), this, SLOT(ListenImage()));
    connect(timer, SIGNAL(timeout()), this, SLOT(broadcastDatagram()));
    connect(timer1, SIGNAL(timeout()), this, SLOT(LEDBlinky()));
    connect(timer2, SIGNAL(timeout()), this, SLOT(Msg()));
    //connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
#ifdef Q_OS_SYMBIAN
    connect(sendButton, SIGNAL(clicked()), this, SLOT(returnPressed()));
#endif
    //connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
    connect(&client, SIGNAL(newMessage(QString,QString)),
            this, SLOT(appendMessage(QString,QString)));
    connect(&client, SIGNAL(newParticipant(QString)),
            this, SLOT(newParticipant(QString)));
    connect(&client, SIGNAL(participantLeft(QString)),
            this, SLOT(participantLeft(QString)));
    connect(udpSocket1, SIGNAL(readyRead()),
            this, SLOT(processPendingDatagrams()));
    //connect(this->lbViewImage,SIGNAL(Mouse_Pressed()),this,SLOT(Mouse_Pressed()));

    myNickName = client.nickName();
    newParticipant(myNickName);
    tableFormat.setBorder(0);
    //QTimer::singleShot(1000, this, SLOT(sendID()));
   // led->toggle();
    //timer1->start();
    //timer2->start();

//    QPixmap pix("/home/hoang/Desktop/9-6/sua lai giao dien OBU/OBU/itsheader.png");
//    label->setPixmap(pix);

    QPalette p = this->palette();
    p.setColor(this->backgroundRole(), Qt::gray);
    p.setColor(QPalette::Base, Qt::gray);
    this->setPalette(p);
    pixmap = new QPixmap("./itsheader.png");
    itsheader->setPixmap(*pixmap);
   // textEdit->setTextColor(Qt::yellow);
    //listWidget->(Qt::white);
        //return app.exec();
//    this->lbViewImage->setText("ViewImage!");
//    this->lbViewImage->setTextFormat(Qt::RichText);
//    this->lbViewImage->setTextInteractionFlags(Qt::TextBrowserInteraction);
    //lbViewImage->setOpenExternalLinks(true);
    //QUrl u;
    //u = "link to image";
    //this->textBrowser->append("traffic info:");
    

}

void ChatDialog::startBroadcasting()
{
    //pushButton->setEnabled(false);
    timer->start(1000);
}

void ChatDialog::broadcastDatagram()
{
    //statusLabel->setText(tr("Now broadcasting datagram %1").arg(messageNo));
   // QByteArray datagram = "@3000E2007515150F006013308CA5@33P82234@thongtin@thongtin" + QByteArray::number(messageNo);
    QByteArray datagram = "@3456E123ED98ABCDEDC254652525@thongtin@thongtin";
   udpSocket->writeDatagram(datagram.data(), datagram.size(),
                            QHostAddress::QHostAddress("10.42.43.1") , 45454);
    //udpSocket->writeDatagram(datagram.data(), datagram.size(), QHostAddress::Broadcast , 45454);
    //dpSocket->flush();
    ++messageNo;
}
void ChatDialog::processPendingDatagrams()
{
    while (udpSocket1->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpSocket1->pendingDatagramSize());
        udpSocket1->readDatagram(datagram.data(), datagram.size());
        if(datagram.startsWith("|"))
        {
             this->reRT1();
             client.sendMessage("* " + QString::number(RT));
            // client.sendMessage("* " + time1 +" "+ time2+ QString::number(time2.toInt()-time1.toInt()));
        }
        //lineEdit_2->setText(datagram);
        //statusLabel->setText(tr("Received datagram: \"%1\"")
        // .arg(datagram.data()));}

    }
}


void ChatDialog::appendMessage(const QString &from, const QString &message)
{
//    if(numerr>10)
//    {
//        textEdit->clear();
//        QMessageBox::information(this,"error","connection failed!");
//        return;
//    }
//
//    if (from.isEmpty() || message.isEmpty())
//        return;
    timer->stop();
    if (message.startsWith(QChar('%')))
    {
        //break;

    }
    else
        if (message.startsWith(QChar('@')))
        {
           // break;
        }
    else
    if (message.startsWith(QChar('-')))
    {
        QStringList list;
        list = message.split(QRegExp("\\s+"));
        int Traffic, Weather;
        QString a = list.at(1);
        Traffic = a.toInt();
        QString b = list.at(1);
        Weather = b.toInt();
        switch (Traffic)
        {
        case 1:
            TrafficStatement = "There is an accident ahead!!!";
            timer1->start();
            break;
        case 2:
            TrafficStatement = "There is a traffic-jam ahead!!!";
            timer1->start();
            break;
        case 0:
            TrafficStatement = "Good traffic condition.";
            LEDGreen();
            break;
        default:
            break;
        }
        switch (Weather)
        {
        case 1:
            WeatherStatement = "There is a tornado ahead!!!";
            textBrowser->setTextColor(Qt::darkRed);
            timer2->start();

            break;
        case 2:

            WeatherStatement = "There is a hard rain ahead!!!";
            textBrowser->setTextColor(Qt::darkRed);
            timer2->start();

            //QLabel* pLabel = new QLabel("View Image",this);
            //pLabel->show();
            break;
        case 0:
            WeatherStatement = "Good Weather condition.";
            textBrowser->setTextColor(Qt::green);
            LEDGreen1();
            break;
        default:
            break;
        }
        QTimer::singleShot(15000,timer2,SLOT(stop()));
        this->textBrowser->setHtml("[TRAFFIC CONDITION]: There is a traffic jam ahead!!!<a href='openMyDialog'>ViewImage</a>");
        this->textBrowser->setOpenLinks(false);
        connect(this->textBrowser,SIGNAL(anchorClicked(QUrl)),this,SLOT(ViewImage()));
        this->textBrowser->append("[WEATHER CONDITION]: There is a tornado ahead!!!<a href='openMyDialog'>ViewImage</a>");
        this->textBrowser->append("[WARNING]: EMERGENCY STATE, COME BACK!!!");

//        this->textBrowser->setHtml("[WEATHER CONDITION]: There is a tornado ahead!!!<a href='openMyDialog'>ViewImage</a>");
//        this->textBrowser->setHtml("[WARNING]: There is a tornado ahead!!!<a href='openMyDialog'>ViewImage</a>");

        //textBrowser->append("[TRAFFIC CONDITION]: "+TrafficStatement);
        //textBrowser->append("[WEATHER CONDITION]: "+WeatherStatement);
        //textBrowser->append("[WARNING]: EMERGENCY STATE, COME BACK!!!");
        if (broadcast == 0)
        {
            broadcast++;
        client.sendMessage("%");
    }
    }
else
   if (message.startsWith(QChar('(')))
    {
        this->RTcounter1();
        client.sendMessage("-");

    }
    else
    if (message.startsWith(QChar(')')))
    {
        this->RTcounter();
        QByteArray datagram1 = "=";
     udpSocket->writeDatagram(datagram1.data(), datagram1.size(),
                                QHostAddress::QHostAddress("10.42.43.1") , 45454);
//        udpSocket->writeDatagram(datagram1.data(), datagram1.size(),
//                                 QHostAddress::Broadcast , 45454);
       // client.sendMessage("=");
    }


    
    else
        if (message.startsWith(QChar('+')))
         {
        this->reRT2();
        client.sendMessage("* " + QString::number(RT));

         }
         else
    {
        textEdit->setTextColor(Qt::yellow);
        QTextCursor cursor(textEdit->textCursor());
        cursor.movePosition(QTextCursor::End);
        QTextTable *table = cursor.insertTable(1, 2, tableFormat);
        table->cellAt(0, 0).firstCursorPosition().insertText('<' + from + "> ");
        table->cellAt(0, 1).firstCursorPosition().insertText(message);
        QScrollBar *bar = textEdit->verticalScrollBar();
        bar->setValue(bar->maximum());
    }
}

void ChatDialog::returnPressed()
{


}

void ChatDialog::newParticipant(const QString &nick)
{
    if (nick.isEmpty())
        return;

   // QColor color = textEdit->textColor();


    //this->sendIDr();
    //textEdit->setTextColor(Qt::gray);

        this->sendIDr();

    textEdit->append(tr("* %1 has joined").arg(nick));

    //textEdit->setText("Connected to RSU-GIAIPHONG");

   // textEdit->setText("co ket noi moi");
    //textEdit->setTextColor(Qt::yellow);
    listWidget->addItem(nick);
//    startBroadcasting();

}

void ChatDialog::participantLeft(const QString &nick)
{
    if (nick.isEmpty())
        return;

    QList<QListWidgetItem *> items = listWidget->findItems(nick,
                                                           Qt::MatchExactly);
    if (items.isEmpty())
        return;

    delete items.at(0);
   // QColor color = textEdit->textColor();
    //textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has left").arg(nick));
    textEdit->setTextColor(Qt::yellow);
    broadcast--;
}

void ChatDialog::showInformation()
{
    if (listWidget->count() == 1) {
        QMessageBox::information(this, tr("Chat"),
                                 tr("Launch several instances of this "
                                    "program on your local network and "
                                    "start chatting!"));
    }
}
void ChatDialog::sendID()
{


    //QString text = lineEdit->text();
    QString text = "31589121";
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");

}

void ChatDialog::sendIDr()
{


    //QString text = lineEdit->text();
    QString text = "@ Info Mercedes-Benz 3000E2007515150F006013308CA5 33P82234";
    //QString text = "31589221 DFSDFSDF";
    //client.sendMessage("alo");
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");

}
/////////////////////funtion to count round trip time/////////////////
void ChatDialog::RTcounter()
{
//QTimer::singleShot(10, this, SLOT(ftestBER()));
//QTime t1 = QTime::currentTime();
////QString time3;
//return (t1.toString());

t1.start();
//start = clock();

}
void ChatDialog::RTcounter1()
{
//QTimer::singleShot(10, this, SLOT(ftestBER()));
//QTime t1 = QTime::currentTime();
////QString time3;
//return (t1.toString());

    t2.start();
}
int ChatDialog::reRT(QString time1)
{
    QTime t2 = QTime::currentTime();
    time2 = t2.toString();
    return (time2.toInt()-time1.toInt());
}

void ChatDialog::reRT1()
{
   RT = t1.elapsed();
}
void ChatDialog::reRT2()
{
   RT = t2.elapsed();
}
void ChatDialog::LEDBlinky()
{
   //led->toggle();
}
void ChatDialog::LEDGreen()
{
    //led->setColor("green");
    //led->turnOn();
}
void ChatDialog::LEDBlinky1()
{
   //led_2->toggle();
}
void ChatDialog::LEDGreen1()
{
    //led_2->setColor("green");
    //led_2->turnOn();
}

void ChatDialog::Msg()
{
//    QMessageBox *mbox = new QMessageBox;
//    mbox->setWindowTitle(tr("WARNING"));
//    mbox->setText(text);
//    QPalette palette;
//    palette.setColor(QPalette::Background, Qt::red);
//    mbox->setPalette(palette);
//    QTimer::singleShot(1000, mbox, SLOT(hide()));
//    mbox->show();
    this->ChangeColor1();
    QTimer::singleShot(500, this, SLOT(ChangeColor2()));

}
void ChatDialog::ChangeColor1()
{
    QPalette p = this->palette();
    p.setColor(this->backgroundRole(), Qt::red);
    p.setColor(QPalette::Base, Qt::red);
    this->setPalette(p);
}
void ChatDialog::ChangeColor2()
{
    QPalette p = this->palette();
    p.setColor(this->backgroundRole(), Qt::gray);
    p.setColor(QPalette::Base, Qt::gray);
    this->setPalette(p);
}
void ChatDialog::ImageProcess(QByteArray data)
{

     image.loadFromData(data, "PNG");
     //label_2->setPixmap(QPixmap::fromImage(image));
}

void ChatDialog::ViewImage()
{
    if(image.isNull())
    {
        QMessageBox msg;
        msg.setText("Error");
        msg.setInformativeText("No Image to view!");
        msg.exec();

    }
    else
    {
    label_2->setPixmap(QPixmap::fromImage(image));
    //this->lbViewImage->hide();
    }
}
