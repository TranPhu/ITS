/****************************************************************************
** Meta object code from reading C++ file 'chatdialog.h'
**
** Created: Mon Jul 7 15:59:45 2014
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "chatdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chatdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ChatDialog[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      25,   12,   11,   11, 0x0a,
      56,   11,   11,   11, 0x08,
      77,   72,   11,   11, 0x08,
     101,   72,   11,   11, 0x08,
     126,   11,   11,   11, 0x08,
     144,   11,   11,   11, 0x08,
     175,  170,   11,   11, 0x08,
     202,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ChatDialog[] = {
    "ChatDialog\0\0from,message\0"
    "appendMessage(QString,QString)\0"
    "returnPressed()\0nick\0newParticipant(QString)\0"
    "participantLeft(QString)\0showInformation()\0"
    "processPendingDatagrams()\0data\0"
    "broadcastDatagram(QString)\0sendInfo()\0"
};

const QMetaObject ChatDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ChatDialog,
      qt_meta_data_ChatDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ChatDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ChatDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ChatDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ChatDialog))
        return static_cast<void*>(const_cast< ChatDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int ChatDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: appendMessage((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: returnPressed(); break;
        case 2: newParticipant((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: participantLeft((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: showInformation(); break;
        case 5: processPendingDatagrams(); break;
        case 6: broadcastDatagram((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: sendInfo(); break;
        default: ;
        }
        _id -= 8;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
