/********************************************************************************
** Form generated from reading UI file 'chatdialog.ui'
**
** Created: Mon Jul 7 14:55:36 2014
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATDIALOG_H
#define UI_CHATDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QSplitter>
#include <QtGui/QTableView>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChatDialog
{
public:
    QGridLayout *gridLayout_3;
    QLabel *label_10;
    QGridLayout *gridLayout;
    QComboBox *portBox_2;
    QLabel *label_17;
    QComboBox *baudRateBox_2;
    QLabel *label_19;
    QComboBox *dataBitsBox_2;
    QLabel *label_16;
    QComboBox *parityBox_2;
    QLabel *label_18;
    QComboBox *stopBitsBox_2;
    QLabel *label_9;
    QComboBox *queryModeBox;
    QLabel *label_15;
    QSpinBox *timeoutBox_2;
    QSplitter *splitter_4;
    QPushButton *openCloseButton_2;
    QPushButton *pushButton_2;
    QLabel *label_8;
    QPlainTextEdit *plainTextEdit;
    QSpacerItem *verticalSpacer;
    QLabel *label_20;
    QSplitter *splitter_5;
    QTextEdit *textEdit;
    QListWidget *listWidget;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_2;
    QLabel *label_2;
    QLineEdit *lineEdit_4;
    QLabel *label_4;
    QLineEdit *lineEdit_5;
    QLabel *label_5;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QSplitter *splitter_3;
    QLabel *label;
    QLineEdit *lineEdit;
    QTableView *tableView;
    QHBoxLayout *hboxLayout;

    void setupUi(QDialog *ChatDialog)
    {
        if (ChatDialog->objectName().isEmpty())
            ChatDialog->setObjectName(QString::fromUtf8("ChatDialog"));
        ChatDialog->resize(722, 454);
        gridLayout_3 = new QGridLayout(ChatDialog);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label_10 = new QLabel(ChatDialog);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setPixmap(QPixmap(QString::fromUtf8("itsheader.png")));
        label_10->setScaledContents(true);

        gridLayout_3->addWidget(label_10, 0, 0, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        portBox_2 = new QComboBox(ChatDialog);
        portBox_2->setObjectName(QString::fromUtf8("portBox_2"));

        gridLayout->addWidget(portBox_2, 0, 1, 1, 1);

        label_17 = new QLabel(ChatDialog);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout->addWidget(label_17, 1, 0, 1, 1);

        baudRateBox_2 = new QComboBox(ChatDialog);
        baudRateBox_2->setObjectName(QString::fromUtf8("baudRateBox_2"));

        gridLayout->addWidget(baudRateBox_2, 1, 1, 1, 1);

        label_19 = new QLabel(ChatDialog);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout->addWidget(label_19, 2, 0, 1, 1);

        dataBitsBox_2 = new QComboBox(ChatDialog);
        dataBitsBox_2->setObjectName(QString::fromUtf8("dataBitsBox_2"));

        gridLayout->addWidget(dataBitsBox_2, 2, 1, 1, 1);

        label_16 = new QLabel(ChatDialog);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout->addWidget(label_16, 3, 0, 1, 1);

        parityBox_2 = new QComboBox(ChatDialog);
        parityBox_2->setObjectName(QString::fromUtf8("parityBox_2"));

        gridLayout->addWidget(parityBox_2, 3, 1, 1, 1);

        label_18 = new QLabel(ChatDialog);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout->addWidget(label_18, 4, 0, 1, 1);

        stopBitsBox_2 = new QComboBox(ChatDialog);
        stopBitsBox_2->setObjectName(QString::fromUtf8("stopBitsBox_2"));

        gridLayout->addWidget(stopBitsBox_2, 4, 1, 1, 1);

        label_9 = new QLabel(ChatDialog);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 5, 0, 1, 1);

        queryModeBox = new QComboBox(ChatDialog);
        queryModeBox->setObjectName(QString::fromUtf8("queryModeBox"));

        gridLayout->addWidget(queryModeBox, 5, 1, 1, 1);

        label_15 = new QLabel(ChatDialog);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout->addWidget(label_15, 6, 0, 1, 1);

        timeoutBox_2 = new QSpinBox(ChatDialog);
        timeoutBox_2->setObjectName(QString::fromUtf8("timeoutBox_2"));
        timeoutBox_2->setMinimum(-1);
        timeoutBox_2->setMaximum(10000);
        timeoutBox_2->setSingleStep(10);
        timeoutBox_2->setValue(10);

        gridLayout->addWidget(timeoutBox_2, 6, 1, 1, 1);

        splitter_4 = new QSplitter(ChatDialog);
        splitter_4->setObjectName(QString::fromUtf8("splitter_4"));
        splitter_4->setOrientation(Qt::Horizontal);
        openCloseButton_2 = new QPushButton(splitter_4);
        openCloseButton_2->setObjectName(QString::fromUtf8("openCloseButton_2"));
        splitter_4->addWidget(openCloseButton_2);

        gridLayout->addWidget(splitter_4, 7, 0, 1, 1);

        pushButton_2 = new QPushButton(ChatDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 8, 0, 1, 1);

        label_8 = new QLabel(ChatDialog);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 9, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(ChatDialog);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));

        gridLayout->addWidget(plainTextEdit, 10, 0, 1, 2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 11, 0, 1, 1);

        label_20 = new QLabel(ChatDialog);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout->addWidget(label_20, 0, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 1, 6, 1);

        splitter_5 = new QSplitter(ChatDialog);
        splitter_5->setObjectName(QString::fromUtf8("splitter_5"));
        splitter_5->setOrientation(Qt::Horizontal);
        textEdit = new QTextEdit(splitter_5);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setFocusPolicy(Qt::NoFocus);
        textEdit->setReadOnly(true);
        splitter_5->addWidget(textEdit);
        listWidget = new QListWidget(splitter_5);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setMaximumSize(QSize(180, 16777215));
        listWidget->setFocusPolicy(Qt::NoFocus);
        splitter_5->addWidget(listWidget);

        gridLayout_3->addWidget(splitter_5, 1, 0, 1, 1);

        splitter = new QSplitter(ChatDialog);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        gridLayout_2 = new QGridLayout(layoutWidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        lineEdit_4 = new QLineEdit(layoutWidget);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));

        gridLayout_2->addWidget(lineEdit_4, 0, 1, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_2->addWidget(label_4, 0, 2, 1, 1);

        lineEdit_5 = new QLineEdit(layoutWidget);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));

        gridLayout_2->addWidget(lineEdit_5, 0, 3, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_2->addWidget(label_5, 0, 4, 1, 1);

        lineEdit_3 = new QLineEdit(layoutWidget);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));

        gridLayout_2->addWidget(lineEdit_3, 0, 5, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 0, 6, 1, 1);

        lineEdit_2 = new QLineEdit(layoutWidget);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        gridLayout_2->addWidget(lineEdit_2, 0, 7, 1, 1);

        splitter->addWidget(layoutWidget);

        gridLayout_3->addWidget(splitter, 2, 0, 1, 1);

        splitter_3 = new QSplitter(ChatDialog);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        label = new QLabel(splitter_3);
        label->setObjectName(QString::fromUtf8("label"));
        splitter_3->addWidget(label);
        lineEdit = new QLineEdit(splitter_3);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        splitter_3->addWidget(lineEdit);

        gridLayout_3->addWidget(splitter_3, 3, 0, 1, 1);

        tableView = new QTableView(ChatDialog);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout_3->addWidget(tableView, 4, 0, 1, 1);

        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));

        gridLayout_3->addLayout(hboxLayout, 5, 0, 1, 1);


        retranslateUi(ChatDialog);

        QMetaObject::connectSlotsByName(ChatDialog);
    } // setupUi

    void retranslateUi(QDialog *ChatDialog)
    {
        ChatDialog->setWindowTitle(QApplication::translate("ChatDialog", "RSU-UI", 0, QApplication::UnicodeUTF8));
        label_10->setText(QString());
        label_17->setText(QApplication::translate("ChatDialog", "BaudRate:", 0, QApplication::UnicodeUTF8));
        label_19->setText(QApplication::translate("ChatDialog", "DataBits:", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("ChatDialog", "Parity:", 0, QApplication::UnicodeUTF8));
        label_18->setText(QApplication::translate("ChatDialog", "StopBits:", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("ChatDialog", "QueryMode:", 0, QApplication::UnicodeUTF8));
        label_15->setText(QApplication::translate("ChatDialog", "Timeout:", 0, QApplication::UnicodeUTF8));
        timeoutBox_2->setSuffix(QApplication::translate("ChatDialog", " ms", 0, QApplication::UnicodeUTF8));
        openCloseButton_2->setText(QApplication::translate("ChatDialog", "Open/Close", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("ChatDialog", "Send", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("ChatDialog", "Received:", 0, QApplication::UnicodeUTF8));
        label_20->setText(QApplication::translate("ChatDialog", "Port:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("ChatDialog", "CAR ID: ", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("ChatDialog", "BKS:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("ChatDialog", "RSV:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("ChatDialog", "AVC:", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ChatDialog", "Message:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ChatDialog: public Ui_ChatDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATDIALOG_H
