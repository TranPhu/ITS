#ifndef IMAGECLIENT_H
#define IMAGECLIENT_H

#include <QObject>
#include <QtCore>
#include <QtNetwork>

class ImageClient : public QObject
{
    Q_OBJECT
    public:
        explicit ImageClient(QObject *parent = 0);

    public slots:
        bool connectToHost(QString host);
        bool writeData(QByteArray data);

    private:
        QTcpSocket *socket;
};

#endif // IMAGECLIENT_H
