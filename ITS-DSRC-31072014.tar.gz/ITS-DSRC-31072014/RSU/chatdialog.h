

#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include "ui_chatdialog.h"
#include "client.h"
#include "client.h"
#include "myclient.h"
#include <QDebug>
#include <QtGui>
#include <QtCore>
#include <QtSql>
#include<QUdpSocket>
#include "peermanager.h"
class QUdpSocket;
static QString id2;
class ChatDialog : public QDialog, private Ui::ChatDialog
{
    Q_OBJECT

public:
    ChatDialog(QWidget *parent = 0);

public slots:
    void appendMessage(const QString &from, const QString &message);


private slots:
//    void on_pushButton_clicked();
    void returnPressed();
    void newParticipant(const QString &nick);
    void participantLeft(const QString &nick);
    void showInformation();
    void processPendingDatagrams();
    void broadcastDatagram(QString data);

private:
   int time;
   QString time1, time2;
    Client client;
    MyClient myclient;
    //MyServer server;
    QString myNickName;
    QTextTableFormat tableFormat;
    QSqlDatabase db;
    QSqlRelationalTableModel  *model ,*model1, *model2, *model3;
    QUdpSocket *udpSocket;
    QUdpSocket *udpSocket1;
};

#endif
