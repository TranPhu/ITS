
#include <QtGui>

#include "chatdialog.h"
#include "myclient.h"
#include <QDateTime>

ChatDialog::ChatDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUi(this);
    udpSocket = new QUdpSocket(this);
    udpSocket1 = new QUdpSocket(this);
    udpSocket->bind(45454, QUdpSocket::ShareAddress);
    //udpSocket1->bind(54545, QUdpSocket::ShareAddress);
    myclient.start("192.168.18.1",1234);
    lineEdit->setFocusPolicy(Qt::StrongFocus);
    textEdit->setFocusPolicy(Qt::NoFocus);
    textEdit->setReadOnly(true);
    listWidget->setFocusPolicy(Qt::NoFocus);
	lineEdit_2 ->setFocusPolicy(Qt::NoFocus);
    connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
#ifdef Q_OS_SYMBIAN
    connect(sendButton, SIGNAL(clicked()), this, SLOT(returnPressed()));
#endif
    connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
    connect(&client, SIGNAL(newMessage(QString,QString)),
            this, SLOT(appendMessage(QString,QString)));
    connect(&client, SIGNAL(newParticipant(QString)),
            this, SLOT(newParticipant(QString)));
    connect(&client, SIGNAL(participantLeft(QString)),
            this, SLOT(participantLeft(QString)));
    connect(udpSocket, SIGNAL(readyRead()),
            this, SLOT(processPendingDatagrams()));
    myNickName = client.nickName();
    newParticipant(myNickName);
    tableFormat.setBorder(0);
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("LOCALHOST");  // host
    db.setDatabaseName("its");            // database
    db.setUserName("root");                // user
    db.setPassword("hoang");               // password
    db.open();
    model = new QSqlRelationalTableModel(this);
    model1 = new QSqlRelationalTableModel(this);
    model2 = new QSqlRelationalTableModel(this);

    model3 = new QSqlRelationalTableModel(this);

    model->setTable("verhicles");
    model1->setTable("data_warehouses");
    model2->setTable("mass_transports");
    model3->setTable("customers");
    model3->select();
    model3->setEditStrategy(QSqlTableModel::OnRowChange);
    tableView->setModel(model3);
}
void ChatDialog::processPendingDatagrams()
{
}

void ChatDialog::appendMessage(const QString &from, const QString &message)
{
    QString data_warehouse_id,mass_transport_id,price,current_money;
    QString command;
    if (message.startsWith(QChar('-')))
    {
        client.sendMessage("+");
    }
    else if(message.startsWith(QChar('*')))
    {
        QStringList list;
        list = message.split(QRegExp("\\s+"));
    }
    else if(message.startsWith(QChar('I')))
    {
        qDebug()<<"...........OK.........";
    }
    else if(message.startsWith(QChar('@')))
    {
    QStringList list;
    list = message.split(QRegExp("\\s+"));
    lineEdit_2->setText(list.value(1));
    lineEdit_3->setText(list.value(2));
    lineEdit_4->setText(list.value(3));
    lineEdit_5->setText(list.value(4));
    int tiendu,customer_id;
    bool ok;
    QSqlQuery query1,query2,query4,query3,query5,query6,query7,query8,query9,query10,query11;
    id2 = lineEdit_2->text();
    myclient.startTransfer(id2);
    client.sendMessage("@"+id2);
     qDebug()<<"id2: "<<id2;
    query1.exec("SELECT id FROM verhicles");
    query3.exec("SELECT id FROM data_warehouses");
    query5.exec("SELECT id FROM data_warehouses");
    query7.exec("SELECT id FROM mass_transports");
    query9.exec("SELECT id FROM customers");

    //load thong tin thoi tiet tu database
      QSqlQuery Query;
      QString city_id = "24"; //test nen de mac dinh la ID cua Ha noi
      QString temp,hum,info;

      command = QString("SELECT temp FROM weather WHERE city_id = 24");
      Query.exec(command);
      if(Query.first())
      {
            temp = Query.value(0).toString();
            qDebug()<<" temp : "<<temp;
           // client.sendMessage("a" + QString::number(temp.toInt()));
      }
      command = QString("SELECT hum FROM weather WHERE city_id = 24");
      Query.exec(command);
      if(Query.first())
      {
            hum = Query.value(0).toString();
            qDebug()<<" hum : "<<hum;
            //client.sendMessage("a" + QString::number(temp.toInt()));
      }
      command = QString("SELECT info FROM weather WHERE city_id = 24");
      Query.exec(command);
      if(Query.first())
      {
            info = Query.value(0).toString();
            qDebug()<<" info : "<<info;
      }
      QString messa;
      messa = QString(temp+hum+info);
      client.sendMessage("a"+messa);

    /*********************************/
    while(query1.next())
    {
            if(query1.value(0).toString()==id2)
            {
                qDebug()<<"DA VAO DAY";
                command=QString("SELECT data_warehouse_id FROM verhicles WHERE id = '%1'").arg(id2);
                query2.exec(command);
                if(query2.first())
                {
                    data_warehouse_id = query2.value(0).toString();
                    qDebug()<<"data_warehouse_id"<<data_warehouse_id;
                }

            }
    }
    while(query3.next())
    {
        if(query3.value(0).toString()==data_warehouse_id)
        {
            command=QString("SELECT mass_transport_id  FROM data_warehouses WHERE id='%1'").arg(data_warehouse_id);
            query4.exec(command);
            if(query4.first())
            {
                mass_transport_id = query4.value(0).toString();
                qDebug()<<"mass_transport_id"<<mass_transport_id;
            }
        }
    }
    while(query5.next())
    {
        if(query5.value(0).toString()==data_warehouse_id)
        {
            command=QString("SELECT customer_id FROM data_warehouses WHERE id = '%1'").arg(data_warehouse_id);
            query6.exec(command);
            if(query6.first())
            {
                customer_id = query6.value(0).toInt(&ok);
                qDebug()<<"customer_id"<<customer_id;
            }
        }
    }
    while(query7.next())
    {
        if(query7.value(0).toString()==mass_transport_id)
        {
            command=QString("SELECT price FROM mass_transports WHERE id = '%1'").arg(mass_transport_id);
            query8.exec(command);
            if(query8.first())
            {
                price = query8.value(0).toString();
                qDebug()<<"price"<<price;
            }
        }
    }
    while(query9.next())
    {
        if(query9.value(0)==customer_id)
        {
            command=QString("SELECT current_money FROM customers WHERE id = '%1'").arg(customer_id);
            query10.exec(command);
            if(query10.first())
            {
                current_money = query10.value(0).toString();
                qDebug()<<"current_money"<<current_money;
                tiendu = current_money.toInt(&ok,10)-price.toInt(&ok,10);
                qDebug()<<"tiendu"<<tiendu;
                client.sendMessage(QString::number(tiendu));
            }
        }
    }
    //update lai tai khoan khach hang
    command=QString("UPDATE customers SET current_money = %1 WHERE id='%2'").arg(tiendu).arg(customer_id);
    query11.exec(command);
    qDebug()<<"status1"<<command;
}
    else
    {
        QTextCursor cursor(textEdit->textCursor());
        cursor.movePosition(QTextCursor::End);
        QTextTable *table = cursor.insertTable(1, 2, tableFormat);
        table->cellAt(0, 0).firstCursorPosition().insertText('<' + from + "> ");
        table->cellAt(0, 1).firstCursorPosition().insertText(message);
        QScrollBar *bar = textEdit->verticalScrollBar();
        bar->setValue(bar->maximum());
    }
}

void ChatDialog::returnPressed()
{
    QString text = lineEdit->text();
    if (text.isEmpty())
        return;
    if (text.startsWith(QChar('/'))) {
        QColor color = textEdit->textColor();
        textEdit->setTextColor(Qt::red);
        textEdit->append(tr("! Unknown command: %1").arg(text.left(text.indexOf(' '))));
        textEdit->setTextColor(color);
    } else {
        myclient.startTransfer(text);
        client.sendMessage(text);
    }
    lineEdit->clear();
}

void ChatDialog::newParticipant(const QString &nick)
{
    if (nick.isEmpty())
        return;
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has joined").arg(nick));
    textEdit->setTextColor(color);
    listWidget->addItem(nick);
}

void ChatDialog::participantLeft(const QString &nick)
{
    lineEdit_2->clear();
    lineEdit_3->clear();
    lineEdit_4->clear();
    lineEdit_5->clear();
    if (nick.isEmpty())
        return;
    QList<QListWidgetItem *> items = listWidget->findItems(nick,Qt::MatchExactly);
    if (items.isEmpty())
        return;
    delete items.at(0);
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has left").arg(nick));
    textEdit->setTextColor(color);
}

void ChatDialog::showInformation()
{
    if (listWidget->count() == 1) {
        QMessageBox::information(this, tr("Chat"),
                                 tr("Launch several instances of this "
                                    "program on your local network and "
                                    "start chatting!"));
    }
}
void ChatDialog::broadcastDatagram(QString text)
{
    QByteArray data;
    data.append(text);
    udpSocket1->writeDatagram(data.data(), data.size(),
                             QHostAddress::Broadcast , 54545);
}
