/********************************************************************************
** Form generated from reading UI file 'chatdialog.ui'
**
** Created: Wed Jul 30 12:44:45 2014
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATDIALOG_H
#define UI_CHATDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QSplitter>
#include <QtGui/QTableView>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_ChatDialog
{
public:
    QGridLayout *gridLayout;
    QLabel *itsheader;
    QTextEdit *textEdit;
    QListWidget *listWidget;
    QSplitter *splitter;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QLineEdit *lineEdit_5;
    QLabel *label_5;
    QLineEdit *lineEdit_4;
    QSplitter *splitter_3;
    QLabel *label;
    QLineEdit *lineEdit;
    QTableView *tableView;
    QHBoxLayout *hboxLayout;

    void setupUi(QDialog *ChatDialog)
    {
        if (ChatDialog->objectName().isEmpty())
            ChatDialog->setObjectName(QString::fromUtf8("ChatDialog"));
        ChatDialog->resize(919, 452);
        gridLayout = new QGridLayout(ChatDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        itsheader = new QLabel(ChatDialog);
        itsheader->setObjectName(QString::fromUtf8("itsheader"));
        itsheader->setPixmap(QPixmap(QString::fromUtf8("itsheader.png")));

        gridLayout->addWidget(itsheader, 0, 0, 1, 2);

        textEdit = new QTextEdit(ChatDialog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setFocusPolicy(Qt::NoFocus);
        textEdit->setReadOnly(true);

        gridLayout->addWidget(textEdit, 1, 0, 1, 1);

        listWidget = new QListWidget(ChatDialog);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setMaximumSize(QSize(180, 16777215));
        listWidget->setFocusPolicy(Qt::NoFocus);

        gridLayout->addWidget(listWidget, 1, 1, 1, 1);

        splitter = new QSplitter(ChatDialog);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        lineEdit_2 = new QLineEdit(splitter);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        splitter->addWidget(lineEdit_2);
        label_4 = new QLabel(splitter);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter->addWidget(label_4);
        lineEdit_3 = new QLineEdit(splitter);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        splitter->addWidget(lineEdit_3);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        lineEdit_5 = new QLineEdit(splitter);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        splitter->addWidget(lineEdit_5);
        label_5 = new QLabel(splitter);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter->addWidget(label_5);
        lineEdit_4 = new QLineEdit(splitter);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        splitter->addWidget(lineEdit_4);

        gridLayout->addWidget(splitter, 2, 0, 1, 2);

        splitter_3 = new QSplitter(ChatDialog);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        label = new QLabel(splitter_3);
        label->setObjectName(QString::fromUtf8("label"));
        splitter_3->addWidget(label);
        lineEdit = new QLineEdit(splitter_3);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        splitter_3->addWidget(lineEdit);

        gridLayout->addWidget(splitter_3, 3, 0, 1, 1);

        tableView = new QTableView(ChatDialog);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout->addWidget(tableView, 4, 0, 1, 2);

        hboxLayout = new QHBoxLayout();
#ifndef Q_OS_MAC
        hboxLayout->setSpacing(6);
#endif
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));

        gridLayout->addLayout(hboxLayout, 5, 0, 1, 1);

        splitter->raise();
        splitter_3->raise();
        tableView->raise();
        textEdit->raise();
        textEdit->raise();
        listWidget->raise();

        retranslateUi(ChatDialog);

        QMetaObject::connectSlotsByName(ChatDialog);
    } // setupUi

    void retranslateUi(QDialog *ChatDialog)
    {
        ChatDialog->setWindowTitle(QApplication::translate("ChatDialog", "RSU-UI", 0, QApplication::UnicodeUTF8));
        itsheader->setText(QString());
        label_2->setText(QApplication::translate("ChatDialog", "CAR ID: ", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("ChatDialog", "BKS:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("ChatDialog", "AVC:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("ChatDialog", "RSV:", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ChatDialog", "Message:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ChatDialog: public Ui_ChatDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATDIALOG_H
