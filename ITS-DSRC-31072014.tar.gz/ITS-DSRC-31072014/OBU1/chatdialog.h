

#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include "ui_chatdialog.h"
#include "client.h"
#include <QUdpSocket>
#include <peermanager.h>
#include <QTime>
#include "imageserver.h"

class QTimer;
class QUdpSocket;

class ChatDialog : public QDialog, private Ui::ChatDialog
{
    Q_OBJECT

public:
    ChatDialog(QWidget *parent = 0);

public slots:
    void appendMessage(const QString &from, const QString &message);

private slots:
    void on_pushButton_clicked();
    void newParticipant(const QString &nick);
    void participantLeft(const QString &nick);
    void showInformation();
    void sendID();
    void sendIDr();
    void startBroadcasting();
    void broadcastDatagram();
    void processPendingDatagrams();
    void RTcounter();
    void RTcounter1();
    int reRT(QString time1);
    void reRT1();
    void reRT2();
    void ImageProcess(QByteArray data);
    void ViewImage();

private:
    Client client;
    PeerManager *peer;
    QString myNickName;
    QString time1, time2;
    QString temp,hum,info;

    QTextTableFormat tableFormat;
    int k;
    int numerr;
    int testBER;
    int RT;
    int start;
    //QString time1;
    QUdpSocket *udpSocket;
    QUdpSocket *udpSocket1;
    QTimer *timer;
    int messageNo;
    QHostAddress IP;
    QTime t1;
    QTime t2;
    QPixmap *pixmap;
    ImageServer server;
    QImage image;
    bool view;
};

#endif
