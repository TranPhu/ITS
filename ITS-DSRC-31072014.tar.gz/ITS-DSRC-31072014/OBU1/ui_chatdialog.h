/********************************************************************************
** Form generated from reading UI file 'chatdialog.ui'
**
** Created: Wed Jul 30 15:48:03 2014
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATDIALOG_H
#define UI_CHATDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpinBox>
#include <QtGui/QSplitter>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_ChatDialog
{
public:
    QGridLayout *gridLayout;
    QLabel *itsheader;
    QTextEdit *textEdit;
    QLabel *IMG;
    QListWidget *listWidget;
    QSplitter *splitter_2;
    QSplitter *splitter;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QSpinBox *spinBox;
    QSpinBox *spinBox_2;
    QPushButton *pushButton;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;

    void setupUi(QDialog *ChatDialog)
    {
        if (ChatDialog->objectName().isEmpty())
            ChatDialog->setObjectName(QString::fromUtf8("ChatDialog"));
        ChatDialog->resize(1165, 466);
        gridLayout = new QGridLayout(ChatDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        itsheader = new QLabel(ChatDialog);
        itsheader->setObjectName(QString::fromUtf8("itsheader"));

        gridLayout->addWidget(itsheader, 0, 1, 1, 3);

        textEdit = new QTextEdit(ChatDialog);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setFocusPolicy(Qt::NoFocus);
        textEdit->setReadOnly(true);

        gridLayout->addWidget(textEdit, 1, 1, 2, 1);

        IMG = new QLabel(ChatDialog);
        IMG->setObjectName(QString::fromUtf8("IMG"));
        IMG->setMinimumSize(QSize(471, 300));

        gridLayout->addWidget(IMG, 1, 2, 1, 1);

        listWidget = new QListWidget(ChatDialog);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setMaximumSize(QSize(180, 16777215));
        listWidget->setFocusPolicy(Qt::NoFocus);

        gridLayout->addWidget(listWidget, 1, 3, 2, 1);

        splitter_2 = new QSplitter(ChatDialog);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        splitter_2->addWidget(splitter);

        gridLayout->addWidget(splitter_2, 2, 0, 1, 1);

        groupBox = new QGroupBox(ChatDialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(0, 91));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        spinBox = new QSpinBox(groupBox);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));

        gridLayout_2->addWidget(spinBox, 0, 0, 1, 1);

        spinBox_2 = new QSpinBox(groupBox);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));

        gridLayout_2->addWidget(spinBox_2, 0, 1, 1, 1);

        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_2->addWidget(pushButton, 0, 2, 2, 1);

        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));

        gridLayout_2->addWidget(radioButton, 1, 0, 1, 1);

        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));

        gridLayout_2->addWidget(radioButton_2, 1, 1, 1, 1);


        gridLayout->addWidget(groupBox, 2, 2, 1, 1);


        retranslateUi(ChatDialog);

        QMetaObject::connectSlotsByName(ChatDialog);
    } // setupUi

    void retranslateUi(QDialog *ChatDialog)
    {
        ChatDialog->setWindowTitle(QApplication::translate("ChatDialog", "OBU-UI", 0, QApplication::UnicodeUTF8));
        itsheader->setText(QString());
        IMG->setText(QString());
        groupBox->setTitle(QApplication::translate("ChatDialog", "Option", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("ChatDialog", "View Image", 0, QApplication::UnicodeUTF8));
        radioButton->setText(QApplication::translate("ChatDialog", "Xem anh roi rac", 0, QApplication::UnicodeUTF8));
        radioButton_2->setText(QApplication::translate("ChatDialog", "xem anh auto", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ChatDialog: public Ui_ChatDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATDIALOG_H
