#include <QtGui>
#include "chatdialog.h"
#include "imageserver.h"
bool ip;
ChatDialog::ChatDialog(QWidget *parent)
    : QDialog(parent)
{
    view = 0;
    RT = 0;
    setupUi(this);
    k=0;
    numerr=0;
    testBER=0;
    textEdit->setFocusPolicy(Qt::NoFocus);
    textEdit->setReadOnly(true);
    listWidget->setFocusPolicy(Qt::NoFocus);

    timer = new QTimer(this);
    udpSocket = new QUdpSocket(this);
    udpSocket1 = new QUdpSocket(this);
    messageNo = 1;

#ifdef Q_OS_SYMBIAN
    connect(sendButton, SIGNAL(clicked()), this, SLOT(returnPressed()));
#endif
    connect(&server, SIGNAL(dataReceived(QByteArray)),this, SLOT(ImageProcess(QByteArray)));

    connect(&client, SIGNAL(newMessage(QString,QString)),this, SLOT(appendMessage(QString,QString)));
    connect(&client, SIGNAL(newParticipant(QString)),this, SLOT(newParticipant(QString)));
    connect(&client, SIGNAL(participantLeft(QString)),this, SLOT(participantLeft(QString)));
    connect(udpSocket1, SIGNAL(readyRead()),this, SLOT(processPendingDatagrams()));

    myNickName = client.nickName();
    newParticipant(myNickName);
    tableFormat.setBorder(0);
    pixmap = new QPixmap("./itsheader.png");
    itsheader->setPixmap(*pixmap);
}

void ChatDialog::startBroadcasting()
{
   // timer->start(1000);
}

void ChatDialog::broadcastDatagram()
{/*
    QByteArray datagram = "@AR@33P12345@thongtin@thongtin";
    udpSocket->writeDatagram(datagram.data(), datagram.size(),
                             QHostAddress::Broadcast , 45454);
    ++messageNo;*/
}
void ChatDialog::processPendingDatagrams()
{
    while (udpSocket1->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpSocket1->pendingDatagramSize());
        udpSocket1->readDatagram(datagram.data(), datagram.size());
        if(datagram.startsWith("|"))
        {
             this->reRT1();
             client.sendMessage("* " + QString::number(RT));
        }
    }
}
void ChatDialog::appendMessage(const QString &from, const QString &message)
{
    timer->stop();
    if (message.startsWith(QChar('@')))
     {
        if(message == "@30A0E8D70770406072FA2B20DB00"){
            qDebug()<<"111111111111"<<message;
            ip=true;
        }
        else
            ip=false;
        qDebug()<<"ip co gia tri la: "<<ip;

     }
    else if (message.startsWith(QChar('(')))
    {
        this->RTcounter1();
        client.sendMessage("-");
    }
    else if (message.startsWith(QChar(')')))
    {
        this->RTcounter();
        QByteArray datagram1 = "=";
        udpSocket->writeDatagram(datagram1.data(), datagram1.size(),
                                 QHostAddress::Broadcast , 45454);
    }
    else if (message.startsWith(QChar('+')))
    {
        this->reRT2();
        client.sendMessage("* " + QString::number(RT));
    }
    else if(message.startsWith(QChar('a')))
    {
        qDebug()<<message;
        for(int i=1;i<3;i++)
        {
            temp[i-1]=message[i];
        }
        for(int i=3;i<5;i++)
        {
            hum[i-3]=message[i];
        }
        for(int i=5;i<message.size();i++)
        {
            info[i-5]=message[i];
        }
    }
    else
    {
        if(ip==true)
        {
            QTextCursor cursor(textEdit->textCursor());
            cursor.movePosition(QTextCursor::End);
            QTextTable *table = cursor.insertTable(10, 3, tableFormat);
            table->cellAt(0,0).firstCursorPosition().insertText('<' + from + ">     CHUC QUY KHACH THUONG LO BINH AN");
            table->cellAt(1,0).firstCursorPosition().insertText("* Thu Phi Thanh Cong - So Tien Trong Tai Khoan La: "+message+" vnd");
            //hien thi thong tin thoi tiet cho nguoi su dung
            table->cellAt(3,0).firstCursorPosition().insertText("* THONG TIN THOI TIET");
            table->cellAt(4,0).firstCursorPosition().insertText("    $ Khu Vuc  : Ha noi");
            table->cellAt(5,0).firstCursorPosition().insertText("    $ Nhiet Do : " + temp + " Do C");
            table->cellAt(6,0).firstCursorPosition().insertText("    $ Do Am    : " + hum + " %");
            table->cellAt(7,0).firstCursorPosition().insertText("    $ Du Bao   : " + info);

            QScrollBar *bar = textEdit->verticalScrollBar();
            bar->setValue(bar->maximum());
            ip=false;
        }
    }
}
void ChatDialog::newParticipant(const QString &nick)
{
    if (nick.isEmpty())
        return;
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has joined").arg(nick));
    if(k>0)
   sendIDr();
    k++;
    textEdit->setTextColor(color);
    listWidget->addItem(nick);
}
void ChatDialog::participantLeft(const QString &nick)
{
    if (nick.isEmpty())
        return;

    QList<QListWidgetItem *> items = listWidget->findItems(nick,
                                                           Qt::MatchExactly);
    if (items.isEmpty())
        return;

    delete items.at(0);
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has left").arg(nick));
    textEdit->setTextColor(color);
}
void ChatDialog::showInformation()
{
    if (listWidget->count() == 1) {
        QMessageBox::information(this, tr("Chat"),
                                 tr("Launch several instances of this "
                                    "program on your local network and "
                                    "start chatting!"));
    }
}
void ChatDialog::sendID()
{
    QString text = "163908989";
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");
}

void ChatDialog::sendIDr()
{
    QString text = "@ 30A0E8D70770406072FA2B20DB00 35P2-7777 thongtin1 thongtin2";
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");
}
/////////////////////funtion to count round trip time/////////////////
void ChatDialog::RTcounter()
{
    t1.start();
}
void ChatDialog::RTcounter1()
{
    t2.start();
}
int ChatDialog::reRT(QString time1)
{
    QTime t2 = QTime::currentTime();
    time2 = t2.toString();
    return (time2.toInt()-time1.toInt());
}

void ChatDialog::reRT1()
{
   RT = t1.elapsed();
}
void ChatDialog::reRT2()
{
   RT = t2.elapsed();
}
void ChatDialog::ImageProcess(QByteArray data)
{
     image.loadFromData(data, "PNG");
}
void ChatDialog::ViewImage()
{
    if(image.isNull())
    {
        QMessageBox msg;
        msg.setText("Error");
        msg.setInformativeText("No Image to view!");
        msg.exec();

    }
    else
    {
        qDebug()<<"Image khong NULL";
        IMG->setPixmap(QPixmap::fromImage(image));
    }
}

void ChatDialog::on_pushButton_clicked()
{
    ViewImage();
}
