/****************************************************************************
** Meta object code from reading C++ file 'chatdialog.h'
**
** Created: Sun Jul 6 22:00:35 2014
**      by: The Qt Meta Object Compiler version 62 (Qt 4.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "chatdialog.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chatdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ChatDialog[] = {

 // content:
       4,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      25,   12,   11,   11, 0x0a,
      61,   56,   11,   11, 0x08,
      85,   56,   11,   11, 0x08,
     110,   11,   11,   11, 0x08,
     128,   11,   11,   11, 0x08,
     137,   11,   11,   11, 0x08,
     147,   11,   11,   11, 0x08,
     167,   11,   11,   11, 0x08,
     187,   11,   11,   11, 0x08,
     213,   11,   11,   11, 0x08,
     225,   11,   11,   11, 0x08,
     248,  242,  238,   11, 0x08,
     262,   11,   11,   11, 0x08,
     270,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ChatDialog[] = {
    "ChatDialog\0\0from,message\0"
    "appendMessage(QString,QString)\0nick\0"
    "newParticipant(QString)\0"
    "participantLeft(QString)\0showInformation()\0"
    "sendID()\0sendIDr()\0startBroadcasting()\0"
    "broadcastDatagram()\0processPendingDatagrams()\0"
    "RTcounter()\0RTcounter1()\0int\0time1\0"
    "reRT(QString)\0reRT1()\0reRT2()\0"
};

const QMetaObject ChatDialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_ChatDialog,
      qt_meta_data_ChatDialog, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ChatDialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ChatDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ChatDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ChatDialog))
        return static_cast<void*>(const_cast< ChatDialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int ChatDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: appendMessage((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 1: newParticipant((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: participantLeft((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: showInformation(); break;
        case 4: sendID(); break;
        case 5: sendIDr(); break;
        case 6: startBroadcasting(); break;
        case 7: broadcastDatagram(); break;
        case 8: processPendingDatagrams(); break;
        case 9: RTcounter(); break;
        case 10: RTcounter1(); break;
        case 11: { int _r = reRT((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 12: reRT1(); break;
        case 13: reRT2(); break;
        default: ;
        }
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
