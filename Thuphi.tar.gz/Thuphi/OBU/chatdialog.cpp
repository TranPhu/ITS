

#include <QtGui>

#include "chatdialog.h"


ChatDialog::ChatDialog(QWidget *parent)
    : QDialog(parent)
{
    //startBroadcasting();
    RT = 0;
    setupUi(this);
    k=0;
    numerr=0;
    testBER=0;
    //lineEdit->setFocusPolicy(Qt::StrongFocus);
    textEdit->setFocusPolicy(Qt::NoFocus);
    textEdit->setReadOnly(true);
    listWidget->setFocusPolicy(Qt::NoFocus);
    timer = new QTimer(this);
    udpSocket = new QUdpSocket(this);
    udpSocket1 = new QUdpSocket(this);
    //udpSocket->bind(45454, QUdpSocket::ShareAddress);
    udpSocket1->bind(54545, QUdpSocket::ShareAddress);
    messageNo = 1;

   // connect(pushButton, SIGNAL(clicked()), this, SLOT(startBroadcasting()));
    //connect(pushButton_2, SIGNAL(clicked()), this, SLOT(close()));

    connect(timer, SIGNAL(timeout()), this, SLOT(broadcastDatagram()));

    //connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
#ifdef Q_OS_SYMBIAN
    connect(sendButton, SIGNAL(clicked()), this, SLOT(returnPressed()));
#endif
    //connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
    connect(&client, SIGNAL(newMessage(QString,QString)),
            this, SLOT(appendMessage(QString,QString)));
    connect(&client, SIGNAL(newParticipant(QString)),
            this, SLOT(newParticipant(QString)));
    connect(&client, SIGNAL(participantLeft(QString)),
            this, SLOT(participantLeft(QString)));
    connect(udpSocket1, SIGNAL(readyRead()),
            this, SLOT(processPendingDatagrams()));

    myNickName = client.nickName();
    newParticipant(myNickName);
    tableFormat.setBorder(0);
    //QTimer::singleShot(1000, this, SLOT(sendID()));

}

void ChatDialog::startBroadcasting()
{
    //pushButton->setEnabled(false);
    timer->start(1000);
}

void ChatDialog::broadcastDatagram()
{
    //statusLabel->setText(tr("Now broadcasting datagram %1").arg(messageNo));
   // QByteArray datagram = "@3000E2007515150F006013308CA5@33P82234@thongtin@thongtin" + QByteArray::number(messageNo);
    QByteArray datagram = "@AR@33P82234@thongtin@thongtin";
    udpSocket->writeDatagram(datagram.data(), datagram.size(),
                             QHostAddress::Broadcast , 45454);
    //dpSocket->flush();
    ++messageNo;
}
void ChatDialog::processPendingDatagrams()
{
    while (udpSocket1->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpSocket1->pendingDatagramSize());
        udpSocket1->readDatagram(datagram.data(), datagram.size());
        if(datagram.startsWith("|"))
        {


             this->reRT1();
             client.sendMessage("* " + QString::number(RT));
            // client.sendMessage("* " + time1 +" "+ time2+ QString::number(time2.toInt()-time1.toInt()));

        }
        //lineEdit_2->setText(datagram);
        //statusLabel->setText(tr("Received datagram: \"%1\"")
        // .arg(datagram.data()));}

    }
}


void ChatDialog::appendMessage(const QString &from, const QString &message)
{
//    if(numerr>10)
//    {
//        textEdit->clear();
//        QMessageBox::information(this,"error","connection failed!");
//        return;
//    }
//
//    if (from.isEmpty() || message.isEmpty())
//        return;
    timer->stop();
   if (message.startsWith(QChar('(')))
    {
        this->RTcounter1();
        client.sendMessage("-");

    }
    else
    if (message.startsWith(QChar(')')))
    {
        this->RTcounter();
        QByteArray datagram1 = "=";
        udpSocket->writeDatagram(datagram1.data(), datagram1.size(),
                                 QHostAddress::Broadcast , 45454);
       // client.sendMessage("=");
    }


    
    else
        if (message.startsWith(QChar('+')))
         {
        this->reRT2();
        client.sendMessage("* " + QString::number(RT));

         }
         else
    {
        QTextCursor cursor(textEdit->textCursor());
        cursor.movePosition(QTextCursor::End);
        QTextTable *table = cursor.insertTable(1, 2, tableFormat);
        table->cellAt(0, 0).firstCursorPosition().insertText('<' + from + "> ");
        table->cellAt(0, 1).firstCursorPosition().insertText(message);
        QScrollBar *bar = textEdit->verticalScrollBar();
        bar->setValue(bar->maximum());
    }
}



void ChatDialog::newParticipant(const QString &nick)
{
    if (nick.isEmpty())
        return;

    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has joined").arg(nick));
    //textEdit->setText("Connected to RSU-GIAIPHONG");
    if(k>0)
   sendIDr();
    k++;
   // textEdit->setText("co ket noi moi");
    textEdit->setTextColor(color);
    listWidget->addItem(nick);
    //startBroadcasting();

}

void ChatDialog::participantLeft(const QString &nick)
{
    if (nick.isEmpty())
        return;

    QList<QListWidgetItem *> items = listWidget->findItems(nick,
                                                           Qt::MatchExactly);
    if (items.isEmpty())
        return;

    delete items.at(0);
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has left").arg(nick));
    textEdit->setTextColor(color);
}

void ChatDialog::showInformation()
{
    if (listWidget->count() == 1) {
        QMessageBox::information(this, tr("Chat"),
                                 tr("Launch several instances of this "
                                    "program on your local network and "
                                    "start chatting!"));
    }
}
void ChatDialog::sendID()
{


    //QString text = lineEdit->text();
    QString text = "31589121";
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");

}

void ChatDialog::sendIDr()
{


    //QString text = lineEdit->text();
    QString text = "@ 3000E2007515150F006013308CA5 33P82234 thongtin thongtin";
    //QString text = "31589221 DFSDFSDF";
    client.sendMessage(text);
    textEdit->setText("ID has been sent!");

}
/////////////////////funtion to count round trip time/////////////////
void ChatDialog::RTcounter()
{
//QTimer::singleShot(10, this, SLOT(ftestBER()));
//QTime t1 = QTime::currentTime();
////QString time3;
//return (t1.toString());

t1.start();
//start = clock();

}
void ChatDialog::RTcounter1()
{
//QTimer::singleShot(10, this, SLOT(ftestBER()));
//QTime t1 = QTime::currentTime();
////QString time3;
//return (t1.toString());

    t2.start();
}
int ChatDialog::reRT(QString time1)
{
    QTime t2 = QTime::currentTime();
    time2 = t2.toString();
    return (time2.toInt()-time1.toInt());
}

void ChatDialog::reRT1()
{
   RT = t1.elapsed();
}
void ChatDialog::reRT2()
{
   RT = t2.elapsed();
}
