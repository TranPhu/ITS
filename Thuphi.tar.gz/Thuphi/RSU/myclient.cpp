#include "myclient.h"
#include <QHostAddress>

MyClient::MyClient(QObject* parent): QObject(parent)
{
  //connect(&myclient, SIGNAL(connected()),
    //this, SLOT(startTransfer()));
}

MyClient::~MyClient()
{
  myclient.close();
}

void MyClient::start(QString address, quint16 port)
{
  QHostAddress addr(address);
  myclient.connectToHost(address, port);
}

void MyClient::startTransfer(QString text)
{
  myclient.waitForBytesWritten(3000);
  myclient.write(QString(text + "\n").toUtf8());
}
