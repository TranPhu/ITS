
#include <QtGui>

#include "chatdialog.h"
#include "myclient.h"
#include <QDateTime>

ChatDialog::ChatDialog(QWidget *parent)
    : QDialog(parent)
{
    setupUi(this);
    udpSocket = new QUdpSocket(this);
    udpSocket1 = new QUdpSocket(this);
    udpSocket->bind(45454, QUdpSocket::ShareAddress);
    //udpSocket1->bind(54545, QUdpSocket::ShareAddress);
    myclient.start("192.168.18.1",1234);
    lineEdit->setFocusPolicy(Qt::StrongFocus);
    textEdit->setFocusPolicy(Qt::NoFocus);
    textEdit->setReadOnly(true);
    listWidget->setFocusPolicy(Qt::NoFocus);
	lineEdit_2 ->setFocusPolicy(Qt::NoFocus);
    connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
#ifdef Q_OS_SYMBIAN
    connect(sendButton, SIGNAL(clicked()), this, SLOT(returnPressed()));
#endif
    connect(lineEdit, SIGNAL(returnPressed()), this, SLOT(returnPressed()));
    connect(&client, SIGNAL(newMessage(QString,QString)),
            this, SLOT(appendMessage(QString,QString)));
    connect(&client, SIGNAL(newParticipant(QString)),
            this, SLOT(newParticipant(QString)));
    connect(&client, SIGNAL(participantLeft(QString)),
            this, SLOT(participantLeft(QString)));
    connect(udpSocket, SIGNAL(readyRead()),
            this, SLOT(processPendingDatagrams()));
    myNickName = client.nickName();
    newParticipant(myNickName);
    tableFormat.setBorder(0);
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("LOCALHOST");  // host
    db.setDatabaseName("its");            // database
    db.setUserName("root");                // user
    db.setPassword("hoang");               // password
    db.open();
    model = new QSqlRelationalTableModel(this);
    model1 = new QSqlRelationalTableModel(this);
    model2 = new QSqlRelationalTableModel(this);

    model3 = new QSqlRelationalTableModel(this);

    model->setTable("verhicles");
    model1->setTable("data_warehouses");
    model2->setTable("mass_transports");
    model3->setTable("customers");
    //model->setRelation(0,QSqlRelation("wages","id","salary"));
    model3->select();
    model3->setEditStrategy(QSqlTableModel::OnRowChange);
    tableView->setModel(model3);
//QTimer::singleShot(10 * 1000, this, SLOT(showInformation()));
}
void ChatDialog::processPendingDatagrams()
{
    while (udpSocket->hasPendingDatagrams())
    {
        QByteArray datagram;
        datagram.resize(udpSocket->pendingDatagramSize());
        udpSocket->readDatagram(datagram.data(), datagram.size());
        if(datagram.startsWith("="))
        {
            this->broadcastDatagram("|");
            //udpSocket->flush();
           // QByteArray datag;
            //datag.append("xxxxx");
            //udpSocket1->writeDatagram(datag.data(), datag.size(),
                                    // QHostAddress::Broadcast , 54545);
//            QByteArray buffer = "|";
//            buffer=word.toUtf8();
//               //QHostAddress sender;
//               //quint16 senderPort;
//            socketServerc->writeDatagram(datag.data(), datag.size(),
//                                         QHostAddress::Broadcast , 45454);
        }
        else
        if(datagram.startsWith("@"))
        {
        QString id2 ,data_warehouse_id,mass_transport_id,price,current_money;
        QList<QByteArray> list = datagram.split('@');
        lineEdit_2->setText(list.at(1));
        lineEdit_3->setText(list.at(2));
        lineEdit_4->setText(list.at(3));
        lineEdit_5->setText(list.at(4));
        udpSocket->flush();
        int tiendu,customer_id;
        bool ok;
        QSqlQuery query1,query2,query4,query3,query5,query6,query7,query8,query9,query10,query11;
        id2 = lineEdit_2->text();
        myclient.startTransfer(id2);
        //server.newConnection(id2);
        query1.exec("SELECT id FROM verhicles ");
        query2.exec("SELECT data_warehouse_id  FROM verhicles");
        query3.exec("SELECT id FROM data_warehouses ");
        query4.exec("SELECT mass_transport_id  FROM data_warehouses");
        query5.exec("SELECT id FROM data_warehouses ");
        query6.exec("SELECT customer_id  FROM data_warehouses");
        query7.exec("SELECT id FROM  mass_transports ");
        query8.exec("SELECT price  FROM  mass_transports");
        query9.exec("SELECT id FROM  customers ");
        query10.exec("SELECT current_money  FROM  customers");

        while(query1.next()&&query2.next())
        {
            if(query1.value(0).toString()==id2)
            {
                data_warehouse_id = query2.value(0).toString();
                //client.sendMessage(data_warehouse_id);

            }
        }
        while(query3.next()&&query4.next())
        {
            if(query3.value(0).toString()==data_warehouse_id)
            {
                mass_transport_id = query4.value(0).toString();

                //client.sendMessage(mass_transport_id);
                //client.sendMessage(data_warehouse_id);
            }
        }
        while(query5.next()&&query6.next())
        {
            if(query5.value(0).toString()==data_warehouse_id)
            {
                customer_id = query6.value(0).toInt(&ok);

            }
        }
        while(query7.next()&&query8.next())
        {
            if(query7.value(0).toString()==mass_transport_id)
            {
                price = query8.value(0).toString();

            }
        }
        while(query9.next()&&query10.next())
        {
            if(query9.value(0)==customer_id)
            {
                current_money = query10.value(0).toString();
                tiendu = current_money.toInt(&ok,10)- 10000;

                client.sendMessage(QString::number(tiendu));
                //QByteArray text = id2.toUtf8().left(1000) ;
                //myclient.start("192.168.18.1",1234);
                //myclient.startTransfer(text);

            }
        }
        QString status1=QString("UPDATE customers SET current_money=%1 WHERE id='%2'").arg(tiendu).arg(customer_id);
        query11.exec(status1);
        //statusLabel->setText(tr("Received datagram: \"%1\"")
        // .arg(datagram.data()));}
        }
        else
        {
//            QTextCursor cursor(textEdit->textCursor());
//            cursor.movePosition(QTextCursor::End);
//            QTextTable *table = cursor.insertTable(1, 2, tableFormat);
//            table->cellAt(0, 0).firstCursorPosition().insertText('<' + from + "> ");
//            table->cellAt(0, 1).firstCursorPosition().insertText(message);
//            QScrollBar *bar = textEdit->verticalScrollBar();
//            bar->setValue(bar->maximum());
            textEdit->setText(datagram);
            textEdit->clear();
        }
    }
}

void ChatDialog::appendMessage(const QString &from, const QString &message)
{
    QString id2 ,data_warehouse_id,mass_transport_id,price,current_money;
    if (message.startsWith(QChar('-')))
    {
        client.sendMessage("+");
    }
    else
    if (message.startsWith(QChar('*')))
    {
        QStringList list;
        list = message.split(QRegExp("\\s+"));
        //lineEdit_7->setText(list.value(1));
    }
    else
    if (message.startsWith(QChar('@')))
    {
    QStringList list;
    list = message.split(QRegExp("\\s+"));
    //lineEdit_5->setText(list.at(1));
    //lineEdit_4->setText(list.at(2));
    //lineEdit_3->setText(list.at(3));
    lineEdit_2->setText(list.value(1));
    lineEdit_3->setText(list.value(2));
    lineEdit_4->setText(list.value(3));
    lineEdit_5->setText(list.value(4));
    //QString id2 ,data_warehouse_id;
    int tiendu,customer_id;
    bool ok;
    QSqlQuery query1,query2,query4,query3,query5,query6,query7,query8,query9,query10,query11;
    id2 = lineEdit_2->text();
    myclient.startTransfer(id2);
    //server.newConnection(id2);
    query1.exec("SELECT id FROM verhicles ");
    query2.exec("SELECT data_warehouse_id  FROM verhicles");
    query3.exec("SELECT id FROM data_warehouses ");
    query4.exec("SELECT mass_transport_id  FROM data_warehouses");
    query5.exec("SELECT id FROM data_warehouses ");
    query6.exec("SELECT customer_id  FROM data_warehouses");
    query7.exec("SELECT id FROM  mass_transports ");
    query8.exec("SELECT price  FROM  mass_transports");
    query9.exec("SELECT id FROM  customers ");
    query10.exec("SELECT current_money  FROM  customers");

    while(query1.next()&&query2.next())
    {
        if(query1.value(0).toString()==id2)
        {
            data_warehouse_id = query2.value(0).toString();
            //client.sendMessage(data_warehouse_id);

        }
    }
    while(query3.next()&&query4.next())
    {
        if(query3.value(0).toString()==data_warehouse_id)
        {
            mass_transport_id = query4.value(0).toString();

            //client.sendMessage(mass_transport_id);
            //client.sendMessage(data_warehouse_id);
        }
    }
    while(query5.next()&&query6.next())
    {
        if(query5.value(0).toString()==data_warehouse_id)
        {
            customer_id = query6.value(0).toInt(&ok);

        }
    }
    while(query7.next()&&query8.next())
    {
        if(query7.value(0).toString()==mass_transport_id)
        {
            price = query8.value(0).toString();

        }
    }
    while(query9.next()&&query10.next())
    {
        if(query9.value(0)==customer_id)
        {
            current_money = query10.value(0).toString();
            tiendu = current_money.toInt(&ok,10)-price.toInt(&ok,10);

            client.sendMessage(QString::number(tiendu));
            //QByteArray text = id2.toUtf8().left(1000) ;
            //myclient.start("192.168.18.1",1234);
            //myclient.startTransfer(text);

        }
    }
    QString status1=QString("UPDATE customers SET current_money=%1 WHERE id='%2'").arg(tiendu).arg(customer_id);
    query11.exec(status1);
    /*if(k==0)
    client.sendMessage("/Error!");
    else
    {
        client.sendMessage("so tien con lai la: "+ sotien);
    }*/
    //client.sendMessage("so tien con lai la: "+ sotien);

}

    //client.sendMessage();
//    else
//        if (message.startsWith(QChar('-')))
//        {
//        QTime t2 = QTime::currentTime();
//        time2 = t2.toString();
//        int time = time2.toInt()-time1.toInt();
//        lineEdit_7->setText(QString::number(time));
//        //lineEdit_7->setText(time2 + time1);
//        QStringList list1;
//        list1 = message.split(QRegExp("\\s+"));
//        int BER;
//        BER = (list1.value(1).toInt()/100)*100;
//        lineEdit_6->setText(QString::number(BER)+" %");
//
//            }

    else
    {
        QTextCursor cursor(textEdit->textCursor());
        cursor.movePosition(QTextCursor::End);
        QTextTable *table = cursor.insertTable(1, 2, tableFormat);
        table->cellAt(0, 0).firstCursorPosition().insertText('<' + from + "> ");
        table->cellAt(0, 1).firstCursorPosition().insertText(message);
        QScrollBar *bar = textEdit->verticalScrollBar();
        bar->setValue(bar->maximum());
    }

}

void ChatDialog::returnPressed()
{
    QString text = lineEdit->text();
    if (text.isEmpty())
        return;

    if (text.startsWith(QChar('/'))) {
        QColor color = textEdit->textColor();
        textEdit->setTextColor(Qt::red);
        textEdit->append(tr("! Unknown command: %1")
                         .arg(text.left(text.indexOf(' '))));
        textEdit->setTextColor(color);
    } else {
        //QByteArray text1= text.toUtf8().left(1000) ;
        myclient.startTransfer(text);

        client.sendMessage(text);
        //appendMessage(myNickName, text);
    }

    lineEdit->clear();
}

void ChatDialog::newParticipant(const QString &nick)
{
    if (nick.isEmpty())
        return;

    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has joined").arg(nick));
    textEdit->setTextColor(color);
    listWidget->addItem(nick);
}

void ChatDialog::participantLeft(const QString &nick)
{
    lineEdit_2->clear();
    lineEdit_3->clear();
    lineEdit_4->clear();
    lineEdit_5->clear();
    //lineEdit_6->clear();
    if (nick.isEmpty())
        return;

    QList<QListWidgetItem *> items = listWidget->findItems(nick,
                                                           Qt::MatchExactly);
    if (items.isEmpty())
        return;

    delete items.at(0);
    QColor color = textEdit->textColor();
    textEdit->setTextColor(Qt::gray);
    textEdit->append(tr("* %1 has left").arg(nick));
    textEdit->setTextColor(color);
}

void ChatDialog::showInformation()
{
    if (listWidget->count() == 1) {
        QMessageBox::information(this, tr("Chat"),
                                 tr("Launch several instances of this "
                                    "program on your local network and "
                                    "start chatting!"));
    }
}


void ChatDialog::broadcastDatagram(QString text)
{
    //statusLabel->setText(tr("Now broadcasting datagram %1").arg(messageNo));
   // QByteArray datagram = "@3000E2007515150F006013308CA5@33P82234@thongtin@thongtin" + QByteArray::number(messageNo);
    QByteArray data;
    data.append(text);
    udpSocket1->writeDatagram(data.data(), data.size(),
                             QHostAddress::Broadcast , 54545);
    //dpSocket->flush();
    //++messageNo;
}
