#ifndef MYCLIENT_H
#define MYCLIENT_H

#include <QtNetwork>
#include <QObject>
#include <QString>
#include <QTcpSocket>

class MyClient: public QObject
{
Q_OBJECT
public:
  MyClient(QObject* parent = 0);
  ~MyClient();
  void start(QString address, quint16 port);
public slots:
  void startTransfer(QString text);
private:
  QTcpSocket myclient;
};
#endif


